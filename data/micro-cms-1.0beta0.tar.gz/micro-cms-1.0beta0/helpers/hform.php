<?php
	/*      hform.php - this file is part of Micro CMS
	 *      
	 *      Copyright 2008 Micro CMS
	 * 
	 * 	Authors:
	 * 		- Tihomir Piha <tpiha@kset.org>
	 * 		- Nikola Dušak <vampyr@kset.org>
	 *      
	 *      This program is free software; you can redistribute it and/or modify
	 *      it under the terms of the GNU Lesser General Public License as published by
	 *      the Free Software Foundation; either version 2 of the License, or
	 *      (at your option) any later version.
	 *      
	 *      This program is distributed in the hope that it will be useful,
	 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
	 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	 *      GNU Lesser General Public License for more details.
	 *      
	 *      You should have received a copy of the GNU Lesser General Public License
	 *      along with this program; if not, write to the Free Software
	 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
	 *      MA 02110-1301, USA.
	 *
	 *      Original license: http://www.gnu.org/licenses/lgpl.html
	 */
	
	lloader_load_helper("anchor");
	lloader_load_model("cats");
	
	/* Returns an open form tag
	 * <param> <string> action - string containing form action
	 * <param> <array> attributes - array containing HTML attributes name/value
	 * <return> <string> - returns an open HTML form string
	 */
	function hform_open($action, $attributes = false)
	{
		$attributes_string = "";
		
		if ($attributes) foreach ($attributes as $name => $value) $attributes_string .= ' ' . $name . '="' . $value . '"';

		$action = hanchor_href($action);
		
		return '<form enctype="multipart/form-data" action="' . $action . '" method="post"' . $attributes_string . '>'."\n";
	}
	
	/* Returns a closed form tag
	 * <return> <string> - returns closed html form tag string
	 */
	function hform_close()
	{
		return "</form>";
	}

	/* Validates some form
	 * <param> <array> validate_array - array containing names of variables that should be validated
	 * <return> <boolean> - returns true if form provides data for every variable name from validate array, else false
	 */
	function hform_validate($validate_array, $post_data = false)
	{
		if ($post_data) $data = $post_data;
		else $data = $_POST;
		foreach($validate_array as $name)
		{
			if (!isset($data[$name]) || (is_string($data[$name]) && !strlen($data[$name]))) return false;
			if ($name == "captcha" && (int) $data[$name] != hmessage_get("captcha")) return false;
		}
		return true;
	}

	/* Returns rte (rich text editor or wysiwyg editor control)
	 * <param> <string> name - rte's name
	 * <param> <string> content - initial content
	 * <return> <string> - html for rte
	 */
	function hform_rte($name = "content", $content = "", $width = "600px", $height = "400px")
	{
		$content = str_replace("\r", '', $content);
		$content = str_replace("\n", '', $content);

		$rte_html = 	'<script type="text/javascript" src="'.hanchor_shref().'extern/rte/richtext.js"></script>
				<script language="JavaScript" type="text/javascript">
				<!--
					function submitForm()
					{
						//make sure hidden and iframe values are in sync before submitting form
						updateRTE("'.$name.'");
						return true;
					}
					initRTE("'.hanchor_shref().'extern/rte/images/", "'.hanchor_shref().'extern/rte/", "'.hanchor_shref().'extern/rte/rte.css");
				//-->
				</script>
				<script language="JavaScript" type="text/javascript">
					<!--
					writeRichText("'.$name.'", "'.addslashes($content).'", "'.$width.'", "'.$height.'", true, false);
					var frame = document.getElementById("'.$name.'").parentNode.parentNode.parentNode;
					if (frame) frame.onsubmit = submitForm;
					//-->
				</script>'."\n";

		return $rte_html;
	}

	/* Creates javascript captcha (sum)
	 * <return> <string> - html for captcha
	 */
	function hform_captcha()
	{
		srand(time());
		$random1 = (rand(1, 10));
		$random2 = (rand(1, 10));
		$sum = $random1 + $random2;
		hmessage_set($sum, "captcha");

		$captcha_html = '<script type="text/javascript">document.write("' . $random1 . ' + ' . $random2 . '");</script>';

		return $captcha_html;
	}

	/* Returns ' checked ' if postdata is 1 or '' if 0
	 * <param> <integer> postdata - input ckeckbox data (checked or not)
	 * <return> <string> - html for input checkbox ckecked attribute
	 */
	function hform_checked($postdata)
	{
		return $postdata?" checked ":"";
	}
?>
