function main()
{
	$("#content").fadeIn(1400);
	$("a[@rel*=lightbox]").lightBox();
}

function toggle_fade(element)
{
	var elm = document.getElementById(element);
	if (elm.style.display == "none") $('#' + element).fadeIn(1400);
	else $('#' + element).fadeOut(1400);
}

$(document).ready(main);