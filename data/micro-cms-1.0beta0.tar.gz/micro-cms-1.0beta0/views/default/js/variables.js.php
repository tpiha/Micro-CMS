<?lloader_load_helper("anchor");?>
hanchor_href = "<?=hanchor_shref()?>";