<?php
	lloader_load_helper("anchor");
	lloader_load_helper("string");
	lloader_load_model("categories");

	$data["cats"] = mcategories_read_all_ordered();

	for ($i = 0; $i < count($data["cats"]); $i++)
	{
		$data["cats"][$i]["link"] = mcategories_read_path($data["cats"][$i]["link"], false);
		$data["cats"][$i]["priority"] = 1.00 / count(luri_split($data["cats"][$i]["link"]));
	}

	lloader_load_view("html/sitemap", $data);
?>