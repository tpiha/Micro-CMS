<?='<?xml version="1.0" encoding="UTF-8"?>'?>

<urlset xmlns="http://www.google.com/schemas/sitemap/0.84">
<?foreach($cats as $cat):?>
	<url>
		<loc><?=hanchor_href("main/index/content", $cat["link"])?></loc>
		<lastmod>2009-03-02</lastmod>
		<changefreq>monthly</changefreq>
		<priority>0.</priority>
	</url>
<?endforeach;?>
</urlset>