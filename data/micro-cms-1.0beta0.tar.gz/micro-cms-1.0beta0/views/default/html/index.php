<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

	<head>
		<meta http-equiv="content-Type" content="text/html; charset=utf-8"></meta>
		<title><?=$title?></title>
		<meta name="robots" content="index,follow" />
		<meta name="description" content="<?=@$description?>"></meta>
		<meta name="keywords" content="<?=@$keywords?>"></meta>

		<link rel="stylesheet" type="text/css" href="<?=hanchor_theme("css/style.css")?>" media="screen" />
		<link rel="icon" href="<?=hanchor_theme("img/favicon.ico")?>" />
		<link rel="alternate" type="application/rss+xml" href="<?=hanchor_shref("rss.xml", false)?>" />

		<script type="text/javascript" src="<?=hanchor_href("main/index/js/variables.js", false, false)?>"></script>
		<script type="text/javascript" src="<?=hanchor_shref("extern/jquery_old.js", false)?>"></script>
		<script type="text/javascript" src="<?=hanchor_shref("extern/jquery_lightbox/js/lightbox.js", false)?>"></script>
		<script type="text/javascript" src="<?=hanchor_theme("js/script.js", false, false)?>"></script>
		<link rel="stylesheet" type="text/css" href="<?=hanchor_shref("extern/jquery_lightbox/css/jquery.lightbox-0.5.css", false)?>" media="screen" />
	</head>

	<body>
		<div class="wrapper">

			<div class="header">
				<div class="logo">
					<a href="<?=hanchor_shref()?>"><img src="<?=hanchor_theme("img/micro_cms_logo.jpg")?>" alt="<?=lconf_dbget("title")?>" title="<?=lconf_dbget("title")?>" /></a><br />
					<strong><?=lconf_dbget("description")?></strong>
				</div>
				<div class="menu">
					<ul>
<?php for($i = count($mainmenu) - 1; $i >= 0; $i--): ?>
						<li><a class="<?=hanchor_class("main/item/content", "link1", "link1active", $mainmenu[$i]["link"]);?>" href="<?=hmenu_href("main/item/content", $mainmenu[$i]["link"], @$mainmenu[$i]["url"])?>"><?=$mainmenu[$i]["name"]?></a></li>
<?php endfor; ?>
					</ul>
					<form action="<?=hanchor_href("content/search")?>" class="search" method="post">
						<p>
							<input type="text" value="Keywords" name="keywords" />
							<input type="submit" value="Search" class="submit" />
						</p>
					</form>
				</div>
			</div>

			<div class="crumbs"><?=hbreadcrumbs()?></div>

			<div class="first">
				<ul>
<?php foreach($submenu as $submenu_item): ?>
					<li><a class="<?=hanchor_class("main/index/content", "link1", "link1active", $submenu_item["link"]);?>" href="<?=hmenu_href("main/item/content", @$submenu_item["link"], @$submenu_item["url"])?>"><?=$submenu_item["name"]?></a></li>
<?php endforeach; ?>
				</ul>
			</div>

			<div class="second">
				<div id="content" style="display: none;">
				<div class="content_holder">

					<?lloader_load_view($subview, $data)?>

				</div>
				</div>
			</div>

			<div class="third">
			</div>

			<div class="footer"><div style="float: left;">Powered by <a href="http://tpiha.kset.org/">Micro CMS</a> | <a href="<?=hanchor_href("main/user/admin/admin")?>">Admin</a></div><div style="float: right;">Released under <a href="http://www.gnu.org/copyleft/lesser.html" target="_blank">LGPL</a> license.</div></div>

		</div>
	</body>

</html>
