<div class="sitemap">
						<h2><?=$title?></h2>
<?foreach($cats as $cat):?>
<?if($cat["parentid"] == 0):?>
						<div class="sitemap_block">
						<h4><?=$cat["name"]?></h4>
						<?=hcategories_sitemap($cats, $cat)?>

						</div>
<?endif;?>
<?endforeach;?>
					</div>