						<h2><?=$title?></h2>
						<p><?=hmessage_get();?></p>