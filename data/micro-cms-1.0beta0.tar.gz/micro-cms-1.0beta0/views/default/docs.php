<?php
	lloader_load_helper("breadcrumbs");
	lloader_load_helper("menu");

	$data["subview"] = "subs/message";
	$data["title"] = "Micro CMS docs tool";
	$data["description"] = "browse Micro CMS libraries documentation";
	$data["mainmenu"] = array(array("link" => "docs/controllers", "name" => "Controllers"), array("link" => "docs/helpers", "name" => "Helpers"), array("link" => "docs/libs", "name" => "Libraries"), array("link" => "docs/models", "name" => "Models"));
	$data["submenu"] = array();

	if (!$item)
		foreach($links as $link => $name)
			array_push($data["submenu"], array("link" => "docs/" . $cat . $link, "name" => $name));
	else
	{
		$data["subview"] = "subs/docs";
		foreach($links as $link => $name)
			array_push($data["submenu"], array("url" => hanchor_shref("docs/" . $cat . "/" . $items . "/#" . $link, false), "name" => $name));
	}

	lloader_load_view("html/index", $data);
?>
