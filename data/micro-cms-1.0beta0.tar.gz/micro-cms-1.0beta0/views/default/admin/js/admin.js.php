<?lloader_load_helper("anchor")?>

function admin()
{
	$("#submenu_ul").sortable({stop : update_sortable, axis : "y"});
	$('#date').datepicker({firstDay : 1, dateFormat: 'mm.dd.yy.', nextText: '', prevText: ''});
	$('#content').fadeIn(1400);
}

function make_link(name)
{
	var link = name.toLowerCase();
	link = link.replace(/ /g, "-");
	link = link.replace(/š/gi, "s");
	link = link.replace(/đ/gi, "dj");
	link = link.replace(/ž/gi, "z");
	link = link.replace(/č/gi, "c");
	link = link.replace(/ć/gi, "c");
	document.getElementById("link").value = link;
}

function make_keywords(name)
{
	var link = name.toLowerCase();
	link = link.replace(/ /g, ", ");
	document.getElementById("keywords").value = link;
}

function make_description(name)
{
	document.getElementById("description").value = name;
}

function update_sortable()
{
	var serialized = $("#submenu_ul").sortable("serialize");
	serialized = serialized.replace(/\[\]/g, "");
	serialized = serialized.replace(/item=/g, "");
	var order = serialized.replace(/&/g, "|");

	$.ajax({
		type: "POST",
		url: '<?=hanchor_href("categories/order")?>',
		data: "order=" + order
	});
}

$(document).ready(admin);
