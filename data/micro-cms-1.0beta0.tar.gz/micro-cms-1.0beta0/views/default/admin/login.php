<?php
	lloader_load_helper("anchor");
	lloader_load_helper("form");
	lloader_load_helper("message");
	lloader_load_helper("login");
	lloader_load_model("categories");
	lloader_load_model("settings");
	lloader_load_helper("breadcrumbs");

	$data["title"] = msettings_read("title") . " / " . l("Login");
	$data["admin_title"] = msettings_read("admin_title");
	$data["mainmenu"] = mcategories_read_group(1);
	$data["submenu"] = mcategories_read_group(2);
	$data["subview"] = "admin/subs/login";
	$data["submenu_view"] = "admin/subs/submenu_admin";
	$data["mainmenu_view"] = "admin/subs/mainmenu";

	lloader_load_view("admin/html/index", $data);
?>
