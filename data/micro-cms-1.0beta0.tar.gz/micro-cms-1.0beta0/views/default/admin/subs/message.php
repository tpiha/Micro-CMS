					<div style="height: 300px;">
						<?=hmessage_get() . "\n";?>
					</div>
