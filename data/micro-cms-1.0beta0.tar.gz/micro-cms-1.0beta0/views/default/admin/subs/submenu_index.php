					<ul>
<?php foreach($submenu as $submenu_item): ?>
						<li class="cat"><a class="<?=($submenu_item["link"] == lconf_get("lang") ? "active":"")?>" href="<?=hanchor_href("langs/change_admin", $submenu_item["link"])?>"><?=l($submenu_item["name"])?></a></li>
<?php endforeach; ?>
					</ul>
