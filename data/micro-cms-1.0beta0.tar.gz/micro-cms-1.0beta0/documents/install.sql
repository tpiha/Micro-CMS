-- MySQL dump 10.11
--
-- Host: localhost    Database: micro-cms
-- ------------------------------------------------------
-- Server version	5.0.67-0ubuntu6

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_languages`
--

DROP TABLE IF EXISTS `_languages`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `_languages` (
  `id` int(11) NOT NULL auto_increment,
  `link` varchar(7) collate utf8_slovenian_ci NOT NULL,
  `name` varchar(255) collate utf8_slovenian_ci NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `link` (`link`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_slovenian_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `_languages`
--

LOCK TABLES `_languages` WRITE;
/*!40000 ALTER TABLE `_languages` DISABLE KEYS */;
INSERT INTO `_languages` VALUES (1,'en','English');
/*!40000 ALTER TABLE `_languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `_users`
--

DROP TABLE IF EXISTS `_users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `_users` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(100) collate utf8_slovenian_ci NOT NULL,
  `password` varchar(100) collate utf8_slovenian_ci NOT NULL,
  `key` varchar(100) collate utf8_slovenian_ci NOT NULL,
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_slovenian_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `_users`
--

LOCK TABLES `_users` WRITE;
/*!40000 ALTER TABLE `_users` DISABLE KEYS */;
INSERT INTO `_users` VALUES (1,'admin','21232f297a57a5a743894a0e4a801fc3','6a1c9165094dc2d8faadcd108b72aaae');
/*!40000 ALTER TABLE `_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `en_categories`
--

DROP TABLE IF EXISTS `en_categories`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `en_categories` (
  `id` int(8) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_slovenian_ci NOT NULL,
  `link` varchar(100) collate utf8_slovenian_ci NOT NULL,
  `url` varchar(250) collate utf8_slovenian_ci NOT NULL,
  `description` varchar(255) collate utf8_slovenian_ci NOT NULL,
  `keywords` varchar(255) collate utf8_slovenian_ci NOT NULL,
  `published` tinyint(4) NOT NULL default '1',
  `orderid` smallint(6) NOT NULL default '0',
  `parentid` int(8) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `link` (`link`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8 COLLATE=utf8_slovenian_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `en_categories`
--

LOCK TABLES `en_categories` WRITE;
/*!40000 ALTER TABLE `en_categories` DISABLE KEYS */;
INSERT INTO `en_categories` VALUES (1,'Main menu','main-menu','','','',1,0,0),(2,'Submenu','submenu','','','',1,1,0),(4,'Archive','archive','','','',1,1,1),(5,'Contact','contact','','','',1,2,1),(7,'Test page 1','test1','','','',1,0,2),(8,'Test page 2','test2','','','',1,1,2),(9,'Test page 3','test3','','','',1,2,2),(10,'Todo','todo','','','',1,1,9),(61,'Home','home','','Free lightweight CMS and PHP framework','',1,0,1),(71,'Arhiva 1','arhiva1','','','',1,0,4),(72,'Arhiva 2','arhiva2','','','',1,0,4),(75,'Sitemap','sitemap','','','',1,3,1);
/*!40000 ALTER TABLE `en_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `en_comments`
--

DROP TABLE IF EXISTS `en_comments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `en_comments` (
  `id` int(11) NOT NULL auto_increment,
  `module` varchar(255) collate utf8_slovenian_ci NOT NULL,
  `module_item` varchar(255) collate utf8_slovenian_ci NOT NULL,
  `name` varchar(255) collate utf8_slovenian_ci NOT NULL,
  `body` text collate utf8_slovenian_ci NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_slovenian_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `en_comments`
--

LOCK TABLES `en_comments` WRITE;
/*!40000 ALTER TABLE `en_comments` DISABLE KEYS */;
INSERT INTO `en_comments` VALUES (1,'content','home','Spiro','fdsfdsa f sfds fds afds afsda','2009-03-02 03:34:40'),(2,'content','home','Spiro','fsdafdsa fsd af sda fdsa f sdaf dsa fsd','2009-03-02 03:41:52'),(3,'content','home','Stefo','fsaf sad fsda fds fds af ds','0000-00-00 00:00:00'),(4,'content','home','Test','Test','0000-00-00 00:00:00'),(5,'content','home','afdfdsa','fdsafsda','2009-03-02 04:21:52'),(6,'content','home','fdsafdsa','fdsafdsa','2009-03-02 04:22:40'),(7,'content','home','Pilecki','zadnji test komentara','2009-03-02 04:29:57'),(8,'content','archive','Test','neki novi komentar','2009-03-02 04:35:36'),(9,'content','home','Tihomir','Sedutperspiciatisunde omnis iste natus error sitvoluptatemaccusantiumdoloremquelaudantium, totam rem aperiam, eaqueipsa quaeab illoinventore veritatiset quasi architecto beatae vitaedictasuntexplicabo. Nemo enim ipsamvoluptatem quia voluptas sitaspernaturautodit aut fugit, sed quiaconsequuntur magni dolores eosquirationevoluptatem sequi nesciunt.\r\n','2009-03-02 04:42:29'),(10,'content','archive/arhiva2','fdasfsa','fdsafds','2009-03-02 05:00:40'),(11,'content','home','Trpimir','nfdsadfdsfa','2009-03-02 14:33:33'),(12,'content','home','Do Jaja','neki novi test komentara samo da vidim jel dobro radi vrijeme sad','2009-03-02 18:55:55'),(13,'content','home','Tihomir','fsdfdsa','2009-03-03 03:58:26'),(14,'content','home','Pile','nesto','2009-03-03 03:59:17'),(15,'content','archive/arhiva1','fds','fdsafsd','2009-03-03 04:55:34'),(16,'content','home','Spoler','ja komentiram neki clanak','2009-03-03 19:37:18'),(17,'content','archive/arhiva1','fsdad','fsda','2009-03-04 00:45:21'),(18,'content','archive/arhiva1','Test','test test ','2009-03-04 00:45:32'),(19,'content','archive/arhiva2','Tihomir','Prekrasna slika, nema sta','2009-03-04 03:27:05');
/*!40000 ALTER TABLE `en_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `en_content`
--

DROP TABLE IF EXISTS `en_content`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `en_content` (
  `id` int(11) NOT NULL auto_increment,
  `link` varchar(255) collate utf8_slovenian_ci NOT NULL,
  `name` varchar(255) collate utf8_slovenian_ci NOT NULL,
  `body` longtext collate utf8_slovenian_ci NOT NULL,
  `updated` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `time` datetime NOT NULL,
  `time_published` datetime NOT NULL,
  `author` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `link` (`link`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8 COLLATE=utf8_slovenian_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `en_content`
--

LOCK TABLES `en_content` WRITE;
/*!40000 ALTER TABLE `en_content` DISABLE KEYS */;
INSERT INTO `en_content` VALUES (2,'test1','Test page 1','Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim adminimveniam, quis nostrud exercitation ullamco laboris nisi ut aliquipex eacommodo consequat. Duis aute irure dolor in reprehenderit involuptatevelit esse cillum dolore eu fugiat nulla pariatur. Excepteursintoccaecat cupidatat non proident, sunt in culpa qui officiadeseruntmollit anim id est laborum.<br /><br />Sedut perspiciatis unde omnis iste natus error sit voluptatemaccusantiumdoloremque laudantium, totam rem aperiam, eaque ipsa quaeab illoinventore veritatis et quasi architecto beatae vitae dictasuntexplicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernaturautodit aut fugit, sed quia consequuntur magni dolores eos quirationevoluptatem sequi nesciunt.<br /><br />Neque porro quisquam est, quidolorem ipsumquia dolor sit amet, consectetur, adipisci velit, sed quianon numquameius modi tempora incidunt ut labore et dolore magnamaliquam quaeratvoluptatem.<br />','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0),(3,'test2','Test page 2','Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed doeiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enim adminimveniam, quis nostrud exercitation ullamco laboris nisi ut aliquipex eacommodo consequat. Duis aute irure dolor in reprehenderit involuptatevelit esse cillum dolore eu fugiat nulla pariatur. Excepteursintoccaecat cupidatat non proident, sunt in culpa qui officiadeseruntmollit anim id est laborum.<br /><br />Sedut perspiciatis unde omnis iste natus error sit voluptatemaccusantiumdoloremque laudantium, totam rem aperiam, eaque ipsa quaeab illoinventore veritatis et quasi architecto beatae vitae dictasuntexplicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernaturautodit aut fugit, sed quia consequuntur magni dolores eos quirationevoluptatem sequi nesciunt.<br /><br />Neque porro quisquam est, quidolorem ipsumquia dolor sit amet, consectetur, adipisci velit, sed quianon numquameius modi tempora incidunt ut labore et dolore magnamaliquam quaeratvoluptatem.<br />','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0),(5,'todo','Todo','<strong>MODULI:<br /><br /></strong>- search (content + comments)<br />- languages (dotjerati)<br />- comments<br />- viseportalnost<br />- vise baza<br />- sitemap (xml and real; categories + content)<br />- rss (categories + content)<br />- breadcrumbs (admin + frontend)<br />- wap2 theme<br />- users<br />&nbsp;&nbsp; &nbsp;- groups<br />&nbsp;&nbsp; &nbsp;- permissions<br />&nbsp;&nbsp; &nbsp;- edit, add, delete<br /><br /><strong>OSTALO:<br /><br /></strong>- srediti kesiranje slika kako spada<br />- url kod kategorija<br />- ruta kod kategorija<br />- pri dodavanju i premjestanju kategorije da doda ispravan order id<br />- bug - u docs prikazuje i funkcije iz hardkodiranog javascripta<br />- order stranica po kategorijama u adminu<br />- dodati stvari kod contenta<br />&nbsp;&nbsp; &nbsp;- autor<br />&nbsp;&nbsp; &nbsp;- date i time<br />&nbsp;&nbsp; &nbsp;- date i time kad se objavljuje<br />&nbsp;&nbsp; &nbsp;- prikaz zadnjih clanaka<br />- published (rijesiti do kraja)<br />- popraviti caching da brise nakon promjene<br />- dodati fancy javascript<br />&nbsp;&nbsp; &nbsp;- automatsko upisivanje linka i keywordova (admin)<br />&nbsp;&nbsp; &nbsp;- na frontend jquery<br />&nbsp;&nbsp; &nbsp;- automatski jquery<br />&nbsp;&nbsp; &nbsp;- dodavanje js varijabli<br />- srediti admin (helperi, modeli, konfiguracijski fileovi)<br />- srediti checkboxove u adminu (settings)<br />- srediti css i html (defaultna tema)<br />- urediti 404<br />- srediti rte<br />&nbsp;&nbsp; &nbsp;- urediti kod (prebaciti na doolox core)<br />- popraviti i zavrsiti scaffolding<br />- uklopiti docs i scaffolding u default temu (maknuti main temu)<br />- srediti komentare u kodu<br />- srediti jezicne datoteke','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0),(46,'home','Welcome to Micro CMS','Lorem dolor sit amet, consectetur adipisicing elit,seddoeiusmodtempor incididunt ut labore et dolore magna aliqua. Utenimadminimveniam, quis nostrud exercitation ullamco laboris nisiutaliquipex eacommodo consequat. Duis aute irure dolor inreprehenderitinvoluptatevelit esse cillum dolore eu fugiat nullapariatur.Excepteursintoccaecat cupidatat non proident, sunt in culpaquiofficiadeseruntmollit anim id est laborum.<br /><br />Sedutperspiciatisunde omnis iste natus error sitvoluptatemaccusantiumdoloremquelaudantium, totam rem aperiam, eaqueipsa quaeab illoinventore veritatiset quasi architecto beatae vitaedictasuntexplicabo. Nemo enim ipsamvoluptatem quia voluptas sitaspernaturautodit aut fugit, sed quiaconsequuntur magni dolores eosquirationevoluptatem sequi nesciunt.<br /><br />Nequeporro quisquam est,quidolorem ipsumquia dolor sit amet, consectetur,adipisci velit, sedquianon numquameius modi tempora incidunt ut laboreet doloremagnamaliquam quaeratvoluptatem.<br />','2009-03-02 14:33:23','2009-03-03 12:15:00','0000-00-00 00:00:00',0),(53,'arhiva1','Arhiva 1','fdsafdsaf','0000-00-00 00:00:00','0000-00-00 00:00:00','0000-00-00 00:00:00',0),(54,'arhiva2','Arhiva 2','Lorem ipsum dolor sit amet, consectetur adipisicing elit, seddoeiusmodtempor incididunt ut labore et dolore magna aliqua. Ut enimadminimveniam, quis nostrud exercitation ullamco laboris nisi utaliquipex eacommodo consequat. Duis aute irure dolor in reprehenderitinvoluptatevelit esse cillum dolore eu fugiat nulla pariatur.Excepteursintoccaecat cupidatat non proident, sunt in culpa quiofficiadeseruntmollit anim id est laborum.<br /><br />Sedutperspiciatis unde omnis iste natus error sitvoluptatemaccusantiumdoloremque laudantium, totam rem aperiam, eaqueipsa quaeab illoinventore veritatis et quasi architecto beatae vitaedictasuntexplicabo. Nemo enim ipsam voluptatem quia voluptas sitaspernaturautodit aut fugit, sed quia consequuntur magni dolores eosquirationevoluptatem sequi nesciunt.<br /><br />Neque porro quisquam est,quidolorem ipsumquia dolor sit amet, consectetur, adipisci velit, sedquianon numquameius modi tempora incidunt ut labore et doloremagnamaliquam quaeratvoluptatem.<br />','2009-03-02 18:19:49','1970-01-01 01:00:00','0000-00-00 00:00:00',0);
/*!40000 ALTER TABLE `en_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `en_settings`
--

DROP TABLE IF EXISTS `en_settings`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `en_settings` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_slovenian_ci NOT NULL,
  `value` varchar(255) collate utf8_slovenian_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_slovenian_ci;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `en_settings`
--

LOCK TABLES `en_settings` WRITE;
/*!40000 ALTER TABLE `en_settings` DISABLE KEYS */;
INSERT INTO `en_settings` VALUES (1,'tools','1'),(2,'caching','0'),(3,'title','Micro CMS'),(4,'keywords','micro, cms, lightweight, mobile, free'),(5,'description','Free lightweight CMS ready for mobiles'),(6,'admin_title','Micro CMS - admin panel'),(7,'default_uri','home'),(8,'contact_mail','tpiha@kset.org'),(9,'contact_subject','Micro CMS contact form');
/*!40000 ALTER TABLE `en_settings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-03-04  2:28:50
