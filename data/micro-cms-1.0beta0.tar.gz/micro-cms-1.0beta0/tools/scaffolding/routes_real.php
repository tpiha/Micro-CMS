<?php
		$gconf["routes"]["***NAME***"] = "***NAME***";
		$gconf["routes"]["***NAME***/*"] = "***NAME***/read";
		$gconf["routes"]["***NAME***/create"] = "***NAME***/create";
		$gconf["routes"]["***NAME***/update/*"] = "***NAME***/update";
		$gconf["routes"]["***NAME***/delete/*"] = "***NAME***/delete";
?>
