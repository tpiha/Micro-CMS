<?php
		$gconf["routes"]["scaffolding/***NAME***"] = "***NAME***";
		$gconf["routes"]["scaffolding/***NAME***/*"] = "***NAME***/read";
		$gconf["routes"]["scaffolding/***NAME***/create"] = "***NAME***/create";
		$gconf["routes"]["scaffolding/***NAME***/update/*"] = "***NAME***/update";
		$gconf["routes"]["scaffolding/***NAME***/delete/*"] = "***NAME***/delete";
?>
