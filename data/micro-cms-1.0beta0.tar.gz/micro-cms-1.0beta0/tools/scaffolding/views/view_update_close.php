			<div style="position: relative; height: 10px;"></div>
			<input class="button" type="submit" value="edit" /><input class="button" type="button" value="delete" onclick="window.location.href='<?=hanchor_href(lroute_get_uri_complex("***NAME***/delete") . $***NAME***["id"])?>';" />
		</form>
