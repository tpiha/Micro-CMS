<?php
	/*      mcontent.php - this file is part of Micro CMS
	 *      
	 *      Copyright 2007-PRESENT Micro CMS
	 * 
	 * 	Authors:
	 * 		- Tihomir Piha <tpiha@kset.org>
	 *      
	 *      This program is free software; you can redistribute it and/or modify
	 *      it under the terms of the GNU Lesser General Public License as published by
	 *      the Free Software Foundation; either version 2 of the License, or
	 *      (at your option) any later version.
	 *      
	 *      This program is distributed in the hope that it will be useful,
	 *      but WITHOUT ANY WARRANTY; without even the implied warranty of
	 *      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	 *      GNU Lesser General Public License for more details.
	 *      
	 *      You should have received a copy of the GNU Lesser General Public License
	 *      along with this program; if not, write to the Free Software
	 *      Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
	 *      MA 02110-1301, USA.
	 *
	 *      Original license: http://www.gnu.org/licenses/lgpl.html
	 */

	lloader_load("crud");
	lloader_load("array");
	lloader_load("image");
	lloader_load_conf("content");
	lloader_load_model("categories");

	/* Reads one entry from content table (depending on selected language)
	 * <param> <string/integer> content - link or id
	 * <return> <array> - returns array with result or false on error
	 */
	function mcontent_read($content)
	{
		$table = llang_table("content");

		return lcrud_read_simple($table, $content);
	}

	/* Reads array containing entries from content table
	 * (depending on selected language)
	 * <param> <string/integer> item - parent link or id
	 * <return> <array> - returns array with result or false on error
	 */
	function mcontent_read_group($item)
	{
		$content = array();
		$category = mcategories_read_group($item);

		for ($i = 0; $i < count($category); $i++)
		{
			$cont = mcontent_read($category[$i]["link"]);
			array_push($content, $cont);
		}

		return $content;
	}

	/* Reads all content ordered by id and returns array
	 * <return> <array> - returns array containing categories
	 */
	function mcontent_read_all()
	{
		return lcrud_read(lconf_get("lang") . "_content", "", "ORDER by `id`");
	}

	/* Reads all content ordered by orderid
	 * <return> <array> - returns array containing categories
	 */
	function mcontent_read_all_ordered()
	{
		$content = mcontent_read_all();
		$cats = mcategories_read_all_ordered();
		$new_content = array();

		foreach($cats as $cat)
		{
			foreach($content as $cont)
			{
				if ($cat["link"] == $cont["link"]) array_push($new_content, $cont);
			}
		}

		return $new_content;
	}

	/* Updates content
	 * <param> <string/integer> - id or link of content entry
	 * <param> <array> data - array containing data
	 * <return> <boolean> - returns true on success, false on error
	 */
	function mcontent_update($content, $data)
	{
		$table = llang_table("content");
		$content = mcontent_read($content);
		$data = larray_clean($data, array("link", "name", "body", "time"));

		if ($data["link"] != $content["link"]) limage_update_many(lconf_get("content", "images"), $content["link"], $data["link"]);

		return lcrud_update_simple($table, $content["id"], $data);
	}

	/* Reads category belonging to content
	 * <param> <string/integer> content - id or link of content entry
	 * <return> <array> - returns array containing category
	 */
	function mcontent_get_cat($content)
	{
		$content = mcontent_read($content);
		$cat = mcategories_read($content["link"]);
		return $cat;
	}

	/* Deletes content entry
	 * <param> <string/integer> content - id or link of content entry
	 * <return> <boolean> - returns true on success, false on error
	 */
	function mcontent_delete($content)
	{
		$table = llang_table("content");
		$content = mcontent_read($content);
		limage_delete_many(lconf_get("content", "images"), $content["link"]);

		return lcrud_delete_simple($table, $content["id"]);
	}

	/* Creates content entry
	 * <param> <array> data - array containing data
	 * <return> <boolean> - returns true on success, false on error
	 */
	function mcontent_create($data)
	{
		$table = llang_table("content");
		$data = larray_clean($data, array("link", "name", "body", "time"));
		$data["time_published"] = date("Y-m-d H:i:s", time());
		$data["author"] = lusers_get_cookie_id();
		return lcrud_create($table, $data);
	}
?>
